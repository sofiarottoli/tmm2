//Variables
var input_nombre = document.getElementById("nombre");
var input_pronombre = document.getElementById("pronombre");
var input_mail = document.getElementById("mail");
var input_submit = document.getElementById("boton-enviar");


console.log(input_nombre);
console.log(input_pronombre);
console.log(input_mail);
console.log(input_submit);

input_submit.addEventListener("click", enviarFormulario);

//Obtengo valores inputs
function enviarFormulario(event) {
    event.preventDefault();
    var valor_nombre = input_nombre.value;
    var valor_pronombre = input_pronombre.value;
    var valor_mail = input_mail.value;

    console.log(valor_nombre);
    console.log(valor_pronombre);
    console.log(valor_mail);

}
